export interface Product {
  id: number;
  categoryId: number;
  name: string;
  price: number;
  description: string;
  categoryName: string;
}
