import {Category} from './category';

export const CATEGORIES: Category[] = [
  {id: 1, name: 'Accessories'},
  {id: 2, name: 'Phones'},
  {id: 3, name: 'Tablets'},
  {id: 4, name: 'Watches'},
];
