export interface Admin {
  id: number;
  name: string;
}
