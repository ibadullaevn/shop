import {Product} from './product';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Product 1',
    categoryId: 1,
    categoryName: 'Accessiores',
    description: '',
    price: 1000
  },
  {
    id: 1,
    name: 'Product 1',
    categoryId: 1,
    categoryName: 'Accessiores',
    description: '',
    price: 1000
  },
  {
    id: 1,
    name: 'Product 1',
    categoryId: 1,
    categoryName: 'Accessiores',
    description: '',
    price: 1000
  },
  {
    id: 1,
    name: 'Product 1',
    categoryId: 1,
    categoryName: 'Accessories',
    description: '',
    price: 1000
  },
];
